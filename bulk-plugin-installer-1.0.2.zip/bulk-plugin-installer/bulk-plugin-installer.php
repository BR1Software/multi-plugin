<?php
/**
 * Plugin Name: Bulk Plugin Installer
 * Description: Install multiple plugins from repository slugs, ZIP URLs, or uploaded ZIP files using a manifest text file.
 * Version: 1.0.2
 * Author: BR1 Software Ltd
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BPI_Bulk_Plugin_Installer {
	const MENU_SLUG = 'bpi-bulk-plugin-installer';

	/**
	 * Bootstrap hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
	}

	/**
	 * Add admin page under Tools.
	 */
	public static function register_menu() {
		add_management_page(
			__( 'Bulk Plugin Installer', 'bulk-plugin-installer' ),
			__( 'Bulk Plugin Installer', 'bulk-plugin-installer' ),
			'install_plugins',
			self::MENU_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Render admin UI and process submissions.
	 */
	public static function render_page() {
		if ( ! current_user_can( 'install_plugins' ) ) {
			wp_die( esc_html__( 'You do not have permission to install plugins.', 'bulk-plugin-installer' ) );
		}

		$results      = array();
		$process_log  = array();
		$has_failures = false;

		if ( 'POST' === $_SERVER['REQUEST_METHOD'] && isset( $_POST['bpi_install_plugins'] ) ) {
			check_admin_referer( 'bpi_install_plugins_action', 'bpi_nonce' );
			self::log_event( $process_log, 'info', __( 'Bulk install request received.', 'bulk-plugin-installer' ) );

			$activate_after_install = ! empty( $_POST['bpi_activate_plugins'] );
			self::log_event(
				$process_log,
				'info',
				$activate_after_install
					? __( 'Auto-activation is enabled.', 'bulk-plugin-installer' )
					: __( 'Auto-activation is disabled.', 'bulk-plugin-installer' )
			);
			$parsed_input           = self::parse_manifest_from_upload();

			if ( is_wp_error( $parsed_input ) ) {
				self::log_event( $process_log, 'error', $parsed_input->get_error_message(), __( 'Manifest parsing failed.', 'bulk-plugin-installer' ) );
				$results[] = array(
					'item'   => __( 'Manifest', 'bulk-plugin-installer' ),
					'status' => 'error',
					'message' => $parsed_input->get_error_message(),
				);
			} else {
				self::log_event(
					$process_log,
					'info',
					sprintf(
						/* translators: %d: number of parsed manifest items */
						__( 'Manifest parsed successfully (%d items).', 'bulk-plugin-installer' ),
						count( $parsed_input )
					)
				);
				$uploaded_zips = self::get_uploaded_zip_map();
				self::log_event(
					$process_log,
					'info',
					sprintf(
						/* translators: %d: number of uploaded ZIP files */
						__( 'Uploaded ZIP files available: %d.', 'bulk-plugin-installer' ),
						count( $uploaded_zips )
					)
				);
				$results       = self::install_plugins_from_items( $parsed_input, $uploaded_zips, $activate_after_install, $process_log );
			}

			$has_failures = self::results_have_failures( $results );
			self::log_event(
				$process_log,
				$has_failures ? 'warning' : 'info',
				$has_failures
					? __( 'Install run completed with issues. Review the results and log below.', 'bulk-plugin-installer' )
					: __( 'Install run completed successfully.', 'bulk-plugin-installer' )
			);
		}

		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Bulk Plugin Installer', 'bulk-plugin-installer' ); ?></h1>
			<p><?php esc_html_e( 'Install plugins from repository slugs, direct ZIP URLs, and uploaded ZIP files using a text manifest.', 'bulk-plugin-installer' ); ?></p>
			<p><?php esc_html_e( 'I recommend taking a full backup of your site before using this plugin.', 'bulk-plugin-installer' ); ?></p>

			<form method="post" enctype="multipart/form-data">
				<?php wp_nonce_field( 'bpi_install_plugins_action', 'bpi_nonce' ); ?>

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="bpi_manifest_file"><?php esc_html_e( 'Manifest text file', 'bulk-plugin-installer' ); ?></label></th>
						<td>
							<input type="file" name="bpi_manifest_file" id="bpi_manifest_file" accept=".txt,text/plain" required />
							<p class="description"><?php esc_html_e( 'Upload a .txt file with one source per line.', 'bulk-plugin-installer' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="bpi_zip_files"><?php esc_html_e( 'Local ZIP files (optional)', 'bulk-plugin-installer' ); ?></label></th>
						<td>
							<input type="file" name="bpi_zip_files[]" id="bpi_zip_files" accept=".zip,application/zip" multiple />
							<p class="description"><?php esc_html_e( 'Used for lines like zip:my-plugin.zip in your manifest.', 'bulk-plugin-installer' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Options', 'bulk-plugin-installer' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="bpi_activate_plugins" value="1" />
								<?php esc_html_e( 'Activate plugin after successful install', 'bulk-plugin-installer' ); ?>
							</label>
						</td>
					</tr>
				</table>

				<p class="submit">
					<button type="submit" name="bpi_install_plugins" class="button button-primary"><?php esc_html_e( 'Install Plugins', 'bulk-plugin-installer' ); ?></button>
				</p>
			</form>

			<?php self::render_manifest_help(); ?>
			<?php self::render_feedback_summary( $results ); ?>
			<?php self::render_results( $results ); ?>
			<?php self::render_process_log( $process_log, $has_failures ); ?>
		</div>
		<?php
	}

	/**
	 * Parse the uploaded manifest into structured items.
	 *
	 * @return array|WP_Error
	 */
	private static function parse_manifest_from_upload() {
		if ( empty( $_FILES['bpi_manifest_file'] ) || empty( $_FILES['bpi_manifest_file']['tmp_name'] ) ) {
			return new WP_Error( 'missing_manifest', __( 'Please upload a manifest text file.', 'bulk-plugin-installer' ) );
		}

		$manifest = $_FILES['bpi_manifest_file'];

		if ( ! empty( $manifest['error'] ) ) {
			return new WP_Error( 'manifest_upload_error', __( 'There was an error uploading the manifest file.', 'bulk-plugin-installer' ) );
		}

		$contents = file_get_contents( $manifest['tmp_name'] );

		if ( false === $contents ) {
			return new WP_Error( 'manifest_read_error', __( 'Unable to read the manifest file.', 'bulk-plugin-installer' ) );
		}

		$lines = preg_split( '/\R/', $contents );
		$items = array();

		foreach ( $lines as $line_number => $line ) {
			$raw = trim( $line );

			if ( '' === $raw || 0 === strpos( $raw, '#' ) ) {
				continue;
			}

			$parsed = self::parse_manifest_line( $raw );

			if ( is_wp_error( $parsed ) ) {
				return new WP_Error(
					'invalid_manifest_line',
					sprintf(
						/* translators: 1: line number, 2: error message */
						__( 'Line %1$d: %2$s', 'bulk-plugin-installer' ),
						(int) $line_number + 1,
						$parsed->get_error_message()
					)
				);
			}

			$items[] = $parsed;
		}

		if ( empty( $items ) ) {
			return new WP_Error( 'empty_manifest', __( 'The manifest file contains no installable items.', 'bulk-plugin-installer' ) );
		}

		return $items;
	}

	/**
	 * Parse a single manifest line.
	 *
	 * @param string $line Manifest line.
	 * @return array|WP_Error
	 */
	private static function parse_manifest_line( $line ) {
		$line = trim( $line );

		if ( preg_match( '/^repo:(.+)$/i', $line, $matches ) ) {
			$slug = strtolower( trim( $matches[1] ) );
			if ( ! preg_match( '/^[a-z0-9-]+$/', $slug ) ) {
				return new WP_Error( 'invalid_slug', __( 'Repository slug must contain only lowercase letters, numbers, and dashes.', 'bulk-plugin-installer' ) );
			}

			return array(
				'type'  => 'repo',
				'value' => $slug,
				'label' => 'repo:' . $slug,
			);
		}

		if ( preg_match( '/^url:(.+)$/i', $line, $matches ) ) {
			$url = esc_url_raw( trim( $matches[1] ) );
			if ( empty( $url ) || ! wp_http_validate_url( $url ) ) {
				return new WP_Error( 'invalid_url', __( 'Invalid URL source.', 'bulk-plugin-installer' ) );
			}

			return array(
				'type'  => 'url',
				'value' => $url,
				'label' => 'url:' . $url,
			);
		}

		if ( preg_match( '/^zip:(.+)$/i', $line, $matches ) ) {
			$filename = sanitize_file_name( trim( $matches[1] ) );
			if ( empty( $filename ) || ! preg_match( '/\.zip$/i', $filename ) ) {
				return new WP_Error( 'invalid_zip', __( 'zip: entries must end in .zip and match an uploaded ZIP filename.', 'bulk-plugin-installer' ) );
			}

			return array(
				'type'  => 'zip',
				'value' => $filename,
				'label' => 'zip:' . $filename,
			);
		}

		// Default to repository slug when no prefix is used.
		$slug = strtolower( $line );
		if ( ! preg_match( '/^[a-z0-9-]+$/', $slug ) ) {
			return new WP_Error( 'invalid_line', __( 'Unknown line format. Use slug, repo:, url:, or zip: prefixes.', 'bulk-plugin-installer' ) );
		}

		return array(
			'type'  => 'repo',
			'value' => $slug,
			'label' => $slug,
		);
	}

	/**
	 * Build a map of uploaded ZIP files keyed by sanitized filename.
	 *
	 * @return array<string, string>
	 */
	private static function get_uploaded_zip_map() {
		if ( empty( $_FILES['bpi_zip_files'] ) || ! is_array( $_FILES['bpi_zip_files']['name'] ) ) {
			return array();
		}

		$zip_map = array();
		$names   = $_FILES['bpi_zip_files']['name'];
		$tmp     = $_FILES['bpi_zip_files']['tmp_name'];
		$errors  = $_FILES['bpi_zip_files']['error'];

		foreach ( $names as $index => $original_name ) {
			if ( ! isset( $errors[ $index ] ) || UPLOAD_ERR_OK !== (int) $errors[ $index ] ) {
				continue;
			}

			if ( empty( $tmp[ $index ] ) ) {
				continue;
			}

			$sanitized = sanitize_file_name( $original_name );
			if ( ! preg_match( '/\.zip$/i', $sanitized ) ) {
				continue;
			}

			$zip_map[ $sanitized ] = $tmp[ $index ];
		}

		return $zip_map;
	}

	/**
	 * Install parsed items.
	 *
	 * @param array $items Parsed manifest items.
	 * @param array $uploaded_zips Uploaded ZIP map.
	 * @param bool  $activate_after_install Activate after install.
	 * @return array
	 */
	private static function install_plugins_from_items( $items, $uploaded_zips, $activate_after_install, &$process_log = array() ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

		wp_cache_flush();

		$results = array();
		$seen_sources = array();
		$seen_folders = array();
		$existing_plugin_dirs = self::get_existing_plugin_dir_set();
		self::log_event( $process_log, 'info', __( 'Beginning plugin installation run.', 'bulk-plugin-installer' ) );

		foreach ( $items as $item ) {
			self::log_event( $process_log, 'info', sprintf( __( 'Processing source %s.', 'bulk-plugin-installer' ), $item['label'] ) );
			$source_key = $item['type'] . ':' . $item['value'];
			if ( isset( $seen_sources[ $source_key ] ) ) {
				self::log_event( $process_log, 'warning', __( 'Duplicate manifest entry detected. Entry skipped.', 'bulk-plugin-installer' ), $item['label'] );
				$results[] = array(
					'item'    => $item['label'],
					'status'  => 'warning',
					'message' => __( 'Duplicate manifest entry detected. Skipped to avoid reinstall collision.', 'bulk-plugin-installer' ),
				);
				continue;
			}

			$seen_sources[ $source_key ] = true;

			$inferred_folder = self::infer_plugin_folder_from_item( $item );
			if ( ! empty( $inferred_folder ) ) {
				if ( isset( $seen_folders[ $inferred_folder ] ) ) {
					self::log_event( $process_log, 'warning', __( 'Potential plugin directory collision detected. Entry skipped.', 'bulk-plugin-installer' ), $item['label'] );
					$results[] = array(
						'item'    => $item['label'],
						'status'  => 'warning',
						'message' => sprintf(
							/* translators: %s: manifest source */
							__( 'Potential plugin directory collision with %s. Skipped.', 'bulk-plugin-installer' ),
							$seen_folders[ $inferred_folder ]
						),
					);
					continue;
				}

				if ( isset( $existing_plugin_dirs[ $inferred_folder ] ) ) {
					self::log_event( $process_log, 'warning', __( 'Matching plugin directory already exists. Entry skipped.', 'bulk-plugin-installer' ), $item['label'] );
					$results[] = array(
						'item'    => $item['label'],
						'status'  => 'warning',
						'message' => __( 'A plugin with this directory already exists. Skipped to avoid overwrite collision.', 'bulk-plugin-installer' ),
					);
					continue;
				}

				$seen_folders[ $inferred_folder ] = $item['label'];
			}

			$install_target = '';

			switch ( $item['type'] ) {
				case 'repo':
					self::log_event( $process_log, 'info', __( 'Resolving repository download link.', 'bulk-plugin-installer' ), $item['label'] );
					$download_link = self::get_repo_download_link( $item['value'] );
					if ( is_wp_error( $download_link ) ) {
						self::log_event( $process_log, 'error', $download_link->get_error_message(), $item['label'] );
						$results[] = array(
							'item'    => $item['label'],
							'status'  => 'error',
							'message' => $download_link->get_error_message(),
						);
						continue 2;
					}

					$install_target = $download_link;
					self::log_event( $process_log, 'info', __( 'Repository download link resolved.', 'bulk-plugin-installer' ), $item['label'] );
					break;
				case 'url':
					$install_target = $item['value'];
					self::log_event( $process_log, 'info', __( 'Using direct ZIP URL source.', 'bulk-plugin-installer' ), $item['label'] );
					break;
				case 'zip':
					if ( empty( $uploaded_zips[ $item['value'] ] ) ) {
						self::log_event( $process_log, 'error', __( 'Uploaded ZIP not found for manifest entry.', 'bulk-plugin-installer' ), $item['label'] );
						$results[] = array(
							'item'    => $item['label'],
							'status'  => 'error',
							'message' => __( 'ZIP file not found in uploaded files.', 'bulk-plugin-installer' ),
						);
						continue 2;
					}
					$install_target = $uploaded_zips[ $item['value'] ];
					self::log_event( $process_log, 'info', __( 'Using uploaded ZIP source.', 'bulk-plugin-installer' ), $item['label'] );
					break;
			}

			$skin     = new Automatic_Upgrader_Skin();
			$upgrader = new Plugin_Upgrader( $skin );
			self::log_event( $process_log, 'info', __( 'Starting installation.', 'bulk-plugin-installer' ), $item['label'] );
			$installed = $upgrader->install( $install_target );

			if ( is_wp_error( $installed ) ) {
				self::log_event( $process_log, 'error', $installed->get_error_message(), $item['label'] );
				$results[] = array(
					'item'    => $item['label'],
					'status'  => 'error',
					'message' => $installed->get_error_message(),
				);
				continue;
			}

			if ( false === $installed ) {
				$message = __( 'Installation failed. Check server filesystem permissions or credentials.', 'bulk-plugin-installer' );
				if ( ! empty( $skin->result ) && is_wp_error( $skin->result ) ) {
					$message = $skin->result->get_error_message();
				}
				self::log_event( $process_log, 'error', $message, $item['label'] );

				$results[] = array(
					'item'    => $item['label'],
					'status'  => 'error',
					'message' => $message,
				);
				continue;
			}

			$plugin_file = self::detect_installed_plugin_file( $upgrader, $item );
			self::log_event( $process_log, 'info', __( 'Installation completed successfully.', 'bulk-plugin-installer' ), $item['label'] );

			if ( $activate_after_install && ! empty( $plugin_file ) ) {
				self::log_event( $process_log, 'info', __( 'Attempting activation.', 'bulk-plugin-installer' ), $item['label'] );
				$activation = activate_plugin( $plugin_file );
				if ( is_wp_error( $activation ) ) {
					self::log_event( $process_log, 'warning', $activation->get_error_message(), $item['label'] );
					$results[] = array(
						'item'    => $item['label'],
						'status'  => 'warning',
						'message' => sprintf(
							/* translators: %s: error message */
							__( 'Installed, but activation failed: %s', 'bulk-plugin-installer' ),
							$activation->get_error_message()
						),
					);
					continue;
				}

				$results[] = array(
					'item'    => $item['label'],
					'status'  => 'success',
					'message' => __( 'Installed and activated.', 'bulk-plugin-installer' ),
				);
				self::log_event( $process_log, 'info', __( 'Plugin installed and activated.', 'bulk-plugin-installer' ), $item['label'] );
				continue;
			}

			$results[] = array(
				'item'    => $item['label'],
				'status'  => 'success',
				'message' => __( 'Installed successfully.', 'bulk-plugin-installer' ),
			);
			self::log_event( $process_log, 'info', __( 'Plugin installed successfully.', 'bulk-plugin-installer' ), $item['label'] );

			if ( ! empty( $inferred_folder ) ) {
				$existing_plugin_dirs[ $inferred_folder ] = true;
			}
		}

		self::log_event( $process_log, 'info', __( 'Plugin installation loop finished.', 'bulk-plugin-installer' ) );

		return $results;
	}

	/**
	 * Add a timestamped entry to the process log.
	 *
	 * @param array  $process_log Log entries.
	 * @param string $level Log level.
	 * @param string $message Entry message.
	 * @param string $context Optional context label.
	 */
	private static function log_event( &$process_log, $level, $message, $context = '' ) {
		$timestamp = gmdate( 'Y-m-d H:i:s' ) . ' UTC';
		$prefix    = strtoupper( sanitize_key( (string) $level ) );
		$entry     = '[' . $timestamp . '] [' . $prefix . '] ';

		if ( '' !== $context ) {
			$entry .= '[' . $context . '] ';
		}

		$entry .= wp_strip_all_tags( (string) $message );
		$process_log[] = $entry;
	}

	/**
	 * Check whether results contain any hard failures.
	 *
	 * @param array $results Installation results.
	 * @return bool
	 */
	private static function results_have_failures( $results ) {
		foreach ( $results as $result ) {
			if ( isset( $result['status'] ) && 'error' === $result['status'] ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Render a feedback summary notice for the user.
	 *
	 * @param array $results Installation results.
	 */
	private static function render_feedback_summary( $results ) {
		if ( empty( $results ) ) {
			return;
		}

		$counts = array(
			'success' => 0,
			'warning' => 0,
			'error'   => 0,
		);

		foreach ( $results as $result ) {
			$status = isset( $result['status'] ) ? $result['status'] : 'warning';
			if ( isset( $counts[ $status ] ) ) {
				$counts[ $status ]++;
			}
		}

		$notice_class = 'notice-success';
		if ( $counts['error'] > 0 ) {
			$notice_class = 'notice-error';
		} elseif ( $counts['warning'] > 0 ) {
			$notice_class = 'notice-warning';
		}
		?>
		<div class="notice <?php echo esc_attr( $notice_class ); ?> inline">
			<p>
				<?php
				echo esc_html(
					sprintf(
						/* translators: 1: success count, 2: warning count, 3: error count */
						__( 'Run complete: %1$d successful, %2$d warnings, %3$d errors.', 'bulk-plugin-installer' ),
						$counts['success'],
						$counts['warning'],
						$counts['error']
					)
				);
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * Render execution log and a download button when failures exist.
	 *
	 * @param array $process_log Log entries.
	 * @param bool  $has_failures Whether the run had errors.
	 */
	private static function render_process_log( $process_log, $has_failures ) {
		if ( empty( $process_log ) || ! $has_failures ) {
			return;
		}

		$log_text      = implode( "\n", $process_log );
		$download_name = 'bpi-install-log-' . gmdate( 'Ymd-His' ) . '.txt';
		?>
		<h2><?php esc_html_e( 'Failure Log', 'bulk-plugin-installer' ); ?></h2>
		<p><?php esc_html_e( 'One or more installs failed. Review the log below and download it for troubleshooting or support.', 'bulk-plugin-installer' ); ?></p>
		<p>
			<button type="button" class="button" id="bpi-download-log"><?php esc_html_e( 'Download Log', 'bulk-plugin-installer' ); ?></button>
		</p>
		<textarea id="bpi-process-log" readonly rows="14" style="width:100%;max-width:1000px;font-family:monospace;"><?php echo esc_textarea( $log_text ); ?></textarea>
		<script>
			(function () {
				var button = document.getElementById('bpi-download-log');
				var logField = document.getElementById('bpi-process-log');
				if (!button || !logField) {
					return;
				}

				button.addEventListener('click', function () {
					var blob = new Blob([logField.value], { type: 'text/plain;charset=utf-8' });
					var url = window.URL.createObjectURL(blob);
					var link = document.createElement('a');
					link.href = url;
					link.download = <?php echo wp_json_encode( $download_name ); ?>;
					document.body.appendChild(link);
					link.click();
					document.body.removeChild(link);
					window.URL.revokeObjectURL(url);
				});
			})();
		</script>
		<?php
	}

	/**
	 * Build a set of existing plugin directories keyed by directory name.
	 *
	 * @return array<string, bool>
	 */
	private static function get_existing_plugin_dir_set() {
		$plugins = get_plugins();
		$dirs    = array();

		foreach ( array_keys( $plugins ) as $plugin_file ) {
			$first_segment = strtok( $plugin_file, '/' );
			if ( false !== $first_segment && false === strpos( $first_segment, '.php' ) ) {
				$dirs[ $first_segment ] = true;
			}
		}

		return $dirs;
	}

	/**
	 * Infer plugin directory from a manifest item for collision detection.
	 *
	 * @param array $item Parsed manifest item.
	 * @return string
	 */
	private static function infer_plugin_folder_from_item( $item ) {
		if ( empty( $item['type'] ) || empty( $item['value'] ) ) {
			return '';
		}

		if ( 'repo' === $item['type'] ) {
			return sanitize_file_name( $item['value'] );
		}

		if ( 'zip' === $item['type'] ) {
			$filename = preg_replace( '/\.zip$/i', '', $item['value'] );
			return sanitize_file_name( (string) $filename );
		}

		if ( 'url' === $item['type'] ) {
			$path = wp_parse_url( $item['value'], PHP_URL_PATH );
			if ( empty( $path ) ) {
				return '';
			}

			$filename = basename( $path );
			$filename = preg_replace( '/\.zip$/i', '', $filename );
			return sanitize_file_name( (string) $filename );
		}

		return '';
	}

	/**
	 * Resolve a WordPress.org plugin slug to its ZIP download URL.
	 *
	 * @param string $slug Repository slug.
	 * @return string|WP_Error
	 */
	private static function get_repo_download_link( $slug ) {
		$api = plugins_api(
			'plugin_information',
			array(
				'slug'   => $slug,
				'fields' => array(
					'sections'       => false,
					'tested'         => false,
					'requires'       => false,
					'rating'         => false,
					'downloaded'     => false,
					'last_updated'   => false,
					'added'          => false,
					'tags'           => false,
					'compatibility'  => false,
					'donate_link'    => false,
					'short_description' => false,
				),
			)
		);

		if ( is_wp_error( $api ) ) {
			return new WP_Error(
				'repo_lookup_failed',
				sprintf(
					/* translators: 1: slug, 2: error */
					__( 'Unable to fetch repository plugin "%1$s": %2$s', 'bulk-plugin-installer' ),
					$slug,
					$api->get_error_message()
				)
			);
		}

		if ( empty( $api->download_link ) ) {
			return new WP_Error(
				'repo_no_download_link',
				sprintf(
					/* translators: %s: slug */
					__( 'Repository plugin "%s" has no download link.', 'bulk-plugin-installer' ),
					$slug
				)
			);
		}

		return $api->download_link;
	}

	/**
	 * Locate the newly installed plugin entry file where possible.
	 *
	 * @param Plugin_Upgrader $upgrader Upgrader instance.
	 * @param array           $item Source item.
	 * @return string
	 */
	private static function detect_installed_plugin_file( $upgrader, $item ) {
		if ( ! empty( $upgrader->plugin_info() ) ) {
			return $upgrader->plugin_info();
		}

		if ( 'repo' === $item['type'] ) {
			$plugins = get_plugins( '/' . $item['value'] );
			if ( ! empty( $plugins ) ) {
				$keys = array_keys( $plugins );
				return $item['value'] . '/' . $keys[0];
			}
		}

		return '';
	}

	/**
	 * Output manifest syntax examples.
	 */
	private static function render_manifest_help() {
		?>
		<h2><?php esc_html_e( 'Manifest Examples', 'bulk-plugin-installer' ); ?></h2>
		<pre style="background:#fff;border:1px solid #ccd0d4;padding:12px;max-width:900px;overflow:auto;"># Repository slug (implicit)
akismet

# Repository slug (explicit)
repo:classic-editor

# Direct ZIP URL
url:https://downloads.wordpress.org/plugin/query-monitor.3.16.0.zip

# Uploaded local ZIP file name
zip:my-custom-plugin.zip</pre>
		<?php
	}

	/**
	 * Render results table.
	 *
	 * @param array $results Installation results.
	 */
	private static function render_results( $results ) {
		if ( empty( $results ) ) {
			return;
		}
		?>
		<h2><?php esc_html_e( 'Results', 'bulk-plugin-installer' ); ?></h2>
		<table class="widefat striped" style="max-width:1000px;">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Source', 'bulk-plugin-installer' ); ?></th>
					<th><?php esc_html_e( 'Status', 'bulk-plugin-installer' ); ?></th>
					<th><?php esc_html_e( 'Message', 'bulk-plugin-installer' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $results as $result ) : ?>
					<tr>
						<td><?php echo esc_html( $result['item'] ); ?></td>
						<td>
							<?php
							$status = isset( $result['status'] ) ? $result['status'] : 'info';
							echo esc_html( ucfirst( $status ) );
							?>
						</td>
						<td><?php echo esc_html( $result['message'] ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}
}

BPI_Bulk_Plugin_Installer::init();
